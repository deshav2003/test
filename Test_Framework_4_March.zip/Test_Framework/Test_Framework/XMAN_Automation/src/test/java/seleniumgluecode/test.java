package seleniumgluecode;
import java.io.File;
import java.lang.ref.PhantomReference;
import java.util.concurrent.TimeUnit;

import PageObjects.XMANHomePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import utils.baseTest;
import utils.config;


public class test {

    private WebDriver driver;
    private config conf;

    private XMANHomePage XMANhomePage;

    public test(baseTest basetest, XMANHomePage XMANhomePage){
        driver = basetest.getDriver();
        conf = basetest.getConfig();
        this.XMANhomePage = XMANhomePage;
    }


    @Given("^user is  on homepage$")
    public void user_is_on_homepage() throws Throwable {

        System.out.println("user is on XMAN home page");
        XMANhomePage.clickCummulativeOpen();


    }
    

}