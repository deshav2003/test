package seleniumgluecode;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import org.openqa.selenium.WebDriver;
import utils.baseTest;
import utils.config;

import java.util.concurrent.TimeUnit;

public class InitialSetup {

    private WebDriver driver;
    private config conf;

    public InitialSetup(baseTest basetest){
        driver = basetest.getDriver();
        conf = basetest.getConfig();
    }

    @Before
    public void init() {

        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        driver.get(conf.getProperty("launchurl"));

    }

    @After
    public void tear_down() {
        driver.quit();
    }
}
