package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Wait;
import utils.baseTest;
import utils.config;

public class XMANHomePage {

    private WebDriver driver;
    private Wait wait;

    public XMANHomePage(baseTest basetest){
        driver = basetest.getDriver();
        PageFactory.initElements(driver, this);
    }

   // @FindBy(xpath = "//*[contains(text(),'Home')]")
   @FindBy(xpath = "//*[@class='status-count-table']//[contains(text(),'Trade Reporting')]/following-sibling::[td2]/div")
    private WebElement cummulativeOpen;

    public void clickCummulativeOpen(){
        cummulativeOpen.click();
    }

}
