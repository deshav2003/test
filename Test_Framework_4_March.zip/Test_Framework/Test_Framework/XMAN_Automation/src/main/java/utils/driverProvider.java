package utils;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.concurrent.TimeUnit;

public class driverProvider {

    private static driverProvider drvProvider;
    private WebDriver driver;
    //private String browser;

    private static final Logger LOGGER = LoggerFactory.getLogger(driverProvider.class);

//    private driverProvider(String browser){
//        driver = getDriver(browser);
//    }
//
//    public static driverProvider getInstance(String browser){
//        if(drvProvider == null){
//            drvProvider = new driverProvider(browser);
//        }
//        return drvProvider;
//    }

    public WebDriver getDriver(String browser){

        if(browser.equalsIgnoreCase("chrome")){
            System.setProperty("webdriver.chrome.driver", "src" + File.separator + "main" + File.separator + "resources" + File.separator + "selenium" + File.separator + "automation" + File.separator + "drivers" + File.separator + "chromedriver.exe");
            ChromeOptions options = new ChromeOptions();
            options.addArguments("--start-maximized");
            options.setExperimentalOption("useAutomationExtension", false);
            driver = new ChromeDriver(options);
            if (driver != null) {
                LOGGER.info("Chrome browser launched");
            }

        }

        if(browser.equalsIgnoreCase("ie")){

            System.setProperty("webdriver.ie.driver", "src" + File.separator + "main" + File.separator + "resources" + File.separator + "selenium" +  File.separator + "IEDriverServer.exe");
            DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
            capabilities.setCapability("requireWindowFocus", true);
          //  capabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, false);
            capabilities.setCapability("ignoreZoomSetting", true);
            capabilities.setCapability("ie.ensureCleanSession", true);
            capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
           // capabilities.setCapability(InternetExplorerDriver.FORCE_CREATE_PROCESS, true);
           // capabilities.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
            driver = new InternetExplorerDriver(capabilities);
            if (driver != null) {
                LOGGER.info("IE browser launched");
            }
        }

        if(browser.equalsIgnoreCase("ff")){

        }
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        return driver;
    }

//    public WebDriver getWebDriver() {
//
//        return driver;
//
//    }
}
