package utils;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import org.openqa.selenium.WebDriver;

import java.io.InputStream;
import java.util.Properties;

public class baseTest {

    WebDriver driver = new driverProvider().getDriver("ie");
    config conf = new config();

    public WebDriver getDriver(){
        return driver;
    }

    public config getConfig(){
        return conf;
    }

}
