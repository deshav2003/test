package utils;

import java.io.FileInputStream;
import java.util.Properties;

public class config {

    private static Properties defaultProps = new Properties();
    static {
        try {
            FileInputStream in = new FileInputStream("C:/UBS/Dev/Automation/Test_Framework/Test_Framework/XMAN_Automation/src/test/resources/testdata/config.properties");
            defaultProps.load(in);
            in.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public String getProperty(String key) {
        return defaultProps.getProperty(key);
    }

}
