package com.ubs.utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;

public class driverProvider {

    private static driverProvider drvProvider;
    private WebDriver driver;
    //private String browser;

    private static final Logger LOGGER = LoggerFactory.getLogger(driverProvider.class);

    private driverProvider(String browser){
        driver = getDriver(browser);
    }

    public static driverProvider getInstance(String browser){
        if(drvProvider == null){
            drvProvider = new driverProvider(browser);
        }
        return drvProvider;
    }

    private WebDriver getDriver(String browser){

        if(browser.equalsIgnoreCase("chrome")){
            System.setProperty("webdriver.chrome.driver", "src" + File.separator + "main" + File.separator + "resources" + File.separator + "selenium" + File.separator + "automation" + File.separator + "drivers" + File.separator + "chromedriver.exe");
            ChromeOptions options = new ChromeOptions();
            options.addArguments("--start-maximized");
            options.setExperimentalOption("useAutomationExtension", false);
            driver = new ChromeDriver(options);
            if (driver != null) {
                LOGGER.info("Chrome browser launched");
            }

        }

        if(browser.equalsIgnoreCase("ie")){

        }

        if(browser.equalsIgnoreCase("ff")){

        }
        return driver;
    }

    public WebDriver getWebDriver() {

        return driver;

    }
}
