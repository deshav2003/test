package com.ubs.utils;

import org.openqa.selenium.WebDriver;

public class library {

    private static library lib;
    private WebDriver driver;



    public static library getinstance(WebDriver driver){
        if(lib == null){
            lib = new library(driver);
        }
        return lib;
    }

    private library(WebDriver driver){
        this.driver = driver;
    }

}
