package com.ubs.utils;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import org.openqa.selenium.WebDriver;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class baseTest {

    private driverProvider drvProvider;
    protected WebDriver driver;
    protected library lib;
    protected config conf;


    Properties prop = new Properties();
    InputStream input = null;

    @Before
    public void setUp() {

//        try {
//
//            input = new FileInputStream("src/test/resources/testdata/config.properties");
//            prop.load(input);
//
//        } catch (IOException ex) {
//            ex.printStackTrace();
//        }

     //   conf = new config();


        drvProvider = driverProvider.getInstance("chrome");

        driver = drvProvider.getWebDriver();
        driver.manage().window().maximize();
        lib = library.getinstance(driver);

    }

    @After
    public void tearDown() {

    }
}
