package steps;

import com.ubs.utils.baseTest;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import org.openqa.selenium.WebDriver;

public class exceptionsStepDef extends baseTest{

    @Given("^launch the XMAN application$")
    public void launch_the_XMAN_application(){

           // driver.get(conf.getProperty("launchurl"));
        driver.get("google.com");

    }
}
